export const COM_SHOW_SIDE_BAR = 'COM_SHOW_SIDE_BAR' //边侧栏
export const SET_FULL_SCREEN = 'SET_FULL_SCREEN' // 设置播放器是否全屏幕展示
export const COM_SAVE_SEARCH_HISTORY = 'COM_SAVE_SEARCH_HISTORY' // 保存搜索历史