export const SET_ID = 'SET_ID' // 设置学科
export const SET_USER = 'SET_USER' //设置学科
export const SET_USER_DATA = 'SET_USER_DATA' // 设置用户里程